-- Optional demonstration records. Run only in a test/demo project.
insert into public.vehicles(stock_number,make,model,year,selling_price,status,description)
values
('FT-DEMO-001','Toyota','Fortuner',2020,450000,'available','Demo listing - replace with actual vehicle details'),
('FT-DEMO-002','Toyota','Hilux',2021,520000,'available','Demo listing - replace with actual vehicle details')
on conflict(stock_number) do nothing;
