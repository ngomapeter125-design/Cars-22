create extension if not exists pgcrypto;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,
 role text not null default 'sales_officer' check (role in ('admin','sales_officer','accounts_officer','loan_officer','customer')),
 phone text,
 created_at timestamptz not null default now()
);

create table if not exists public.customers (
 id uuid primary key default gen_random_uuid(),
 full_name text not null,
 phone text not null,
 nrc text unique,
 email text,
 address text,
 occupation text,
 employer text,
 monthly_income numeric(14,2),
 next_of_kin text,
 next_of_kin_phone text,
 created_at timestamptz not null default now()
);

create table if not exists public.vehicles (
 id uuid primary key default gen_random_uuid(),
 stock_number text not null unique,
 make text not null,
 model text not null,
 year integer not null,
 registration_number text,
 vin text unique,
 engine_number text,
 engine_capacity text,
 transmission text,
 fuel_type text,
 mileage integer,
 colour text,
 condition text,
 import_country text,
 purchase_price numeric(14,2) default 0,
 import_cost numeric(14,2) default 0,
 preparation_cost numeric(14,2) default 0,
 selling_price numeric(14,2) not null check(selling_price>=0),
 status text not null default 'available' check(status in ('available','reserved','sold','maintenance','archived')),
 photo_url text,
 description text,
 created_at timestamptz not null default now()
);

create table if not exists public.vehicle_images (
 id uuid primary key default gen_random_uuid(),
 vehicle_id uuid not null references public.vehicles(id) on delete cascade,
 storage_path text not null,
 created_at timestamptz not null default now()
);

create table if not exists public.sales (
 id uuid primary key default gen_random_uuid(),
 sale_number text not null unique,
 customer_id uuid not null references public.customers(id),
 vehicle_id uuid not null references public.vehicles(id),
 selling_price numeric(14,2) not null,
 deposit_amount numeric(14,2) not null default 0,
 payment_type text not null check(payment_type in ('cash','financed','trade_in')),
 status text not null default 'pending',
 sold_by uuid references public.profiles(id),
 created_at timestamptz not null default now(),
 unique(vehicle_id)
);

create table if not exists public.loan_applications (
 id uuid primary key default gen_random_uuid(),
 loan_number text not null unique,
 customer_id uuid not null references public.customers(id),
 vehicle_id uuid not null references public.vehicles(id),
 principal numeric(14,2) not null check(principal>0),
 months integer not null check(months between 1 and 120),
 starting_rate numeric(8,4) not null default 2,
 increment_points numeric(8,4) not null default 1,
 deposit_amount numeric(14,2) not null default 0,
 calculation_method text not null default 'reducing_balance_progressive',
 status text not null default 'pending' check(status in ('pending','under_review','additional_documents','approved','rejected','cancelled')),
 reviewed_by uuid references public.profiles(id),
 reviewed_at timestamptz,
 created_at timestamptz not null default now()
);

create table if not exists public.loan_agreements (
 id uuid primary key default gen_random_uuid(),
 loan_number text not null unique,
 customer_id uuid not null references public.customers(id),
 vehicle_id uuid not null references public.vehicles(id),
 principal numeric(14,2) not null check(principal>0),
 months integer not null check(months between 1 and 120),
 starting_rate numeric(8,4) not null,
 increment_points numeric(8,4) not null,
 calculation_method text not null default 'reducing_balance_progressive',
 total_interest numeric(14,2),
 total_payable numeric(14,2),
 status text not null default 'active' check(status in ('pending','active','settled','defaulted','cancelled')),
 approved_by uuid references public.profiles(id),
 agreement_date date default current_date,
 created_at timestamptz not null default now()
);

create table if not exists public.loan_rate_periods (
 id uuid primary key default gen_random_uuid(),
 loan_id uuid not null references public.loan_agreements(id) on delete cascade,
 month_number integer not null,
 opening_balance numeric(14,2) not null,
 rate_percent numeric(8,4) not null,
 principal_due numeric(14,2) not null,
 interest_due numeric(14,2) not null,
 instalment_due numeric(14,2) not null,
 closing_balance numeric(14,2) not null,
 due_date date,
 status text not null default 'pending' check(status in ('pending','paid','partial','overdue','waived')),
 unique(loan_id,month_number)
);

create table if not exists public.repayment_schedules (
 id uuid primary key default gen_random_uuid(),
 loan_id uuid not null references public.loan_agreements(id) on delete cascade,
 month_number integer not null,
 due_date date not null,
 principal_due numeric(14,2) not null,
 interest_due numeric(14,2) not null,
 amount_due numeric(14,2) not null,
 amount_paid numeric(14,2) not null default 0,
 status text not null default 'pending',
 unique(loan_id,month_number)
);

create table if not exists public.payments (
 id uuid primary key default gen_random_uuid(),
 loan_id uuid not null references public.loan_agreements(id),
 receipt_number text not null unique,
 amount numeric(14,2) not null check(amount>0),
 method text not null,
 reference text,
 received_by uuid references public.profiles(id),
 paid_at timestamptz not null default now(),
 created_at timestamptz not null default now(),
 reversed_at timestamptz,
 reversal_reason text
);

create table if not exists public.payment_allocations (
 id uuid primary key default gen_random_uuid(),
 payment_id uuid not null references public.payments(id),
 schedule_id uuid not null references public.repayment_schedules(id),
 amount numeric(14,2) not null check(amount>0)
);

create table if not exists public.payment_receipts (
 id uuid primary key default gen_random_uuid(),
 payment_id uuid not null unique references public.payments(id),
 document_path text,
 created_at timestamptz not null default now()
);

create table if not exists public.expenses (
 id uuid primary key default gen_random_uuid(),
 category text not null,
 description text not null,
 amount numeric(14,2) not null check(amount>=0),
 supplier text,
 payment_method text,
 receipt_path text,
 recorded_by uuid references public.profiles(id),
 expense_date date not null default current_date,
 created_at timestamptz not null default now()
);

create table if not exists public.suppliers (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 phone text,
 email text,
 created_at timestamptz not null default now()
);

create table if not exists public.documents (
 id uuid primary key default gen_random_uuid(),
 customer_id uuid references public.customers(id),
 vehicle_id uuid references public.vehicles(id),
 loan_id uuid references public.loan_agreements(id),
 document_type text not null,
 storage_path text not null,
 uploaded_by uuid references public.profiles(id),
 created_at timestamptz not null default now()
);

create table if not exists public.notifications (
 id uuid primary key default gen_random_uuid(),
 user_id uuid references public.profiles(id),
 title text not null,
 body text not null,
 read_at timestamptz,
 created_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
 id uuid primary key default gen_random_uuid(),
 actor_id uuid references public.profiles(id),
 action text not null,
 entity_type text not null,
 entity_id uuid,
 details jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);

create table if not exists public.company_settings (
 id integer primary key default 1 check(id=1),
 company_name text not null default 'FAMTREE GENERAL',
 phone text not null default '0972512551',
 email text not null default 'bwalyangulube0210@gmail.com',
 deposit_percent numeric(5,2) not null default 50 check(deposit_percent between 50 and 100),
 starting_rate numeric(8,4) not null default 2,
 increment_points numeric(8,4) not null default 1,
 max_months integer not null default 48,
 logo_path text,
 updated_at timestamptz not null default now()
);

create table if not exists public.financing_plans (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 deposit_percent numeric(5,2) not null default 50 check(deposit_percent between 50 and 100),
 starting_rate numeric(8,4) not null,
 increment_points numeric(8,4) not null,
 duration_months integer not null check(duration_months between 1 and 120),
 calculation_method text not null default 'reducing_balance_progressive',
 active boolean not null default true,
 created_at timestamptz not null default now()
);

create table if not exists public.vehicle_reservations (
 id uuid primary key default gen_random_uuid(),
 vehicle_id uuid not null references public.vehicles(id),
 customer_id uuid not null references public.customers(id),
 reservation_fee numeric(14,2) not null default 0,
 reserved_until timestamptz,
 status text not null default 'active',
 created_at timestamptz not null default now()
);

create table if not exists public.customer_messages (
 id uuid primary key default gen_random_uuid(),
 customer_id uuid references public.customers(id),
 channel text not null,
 message text not null,
 status text not null default 'draft',
 sent_at timestamptz,
 created_at timestamptz not null default now()
);

create index if not exists idx_vehicles_status on public.vehicles(status);
create index if not exists idx_customers_phone on public.customers(phone);
create index if not exists idx_loan_applications_status on public.loan_applications(status);
create index if not exists idx_loans_customer on public.loan_agreements(customer_id);
create index if not exists idx_payments_loan on public.payments(loan_id);
create index if not exists idx_schedule_due on public.repayment_schedules(due_date,status);

insert into public.company_settings(id) values(1) on conflict(id) do nothing;

-- New auth users receive a restricted sales role by default.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
 insert into public.profiles(id,full_name,role)
 values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''), 'sales_officer')
 on conflict(id) do nothing;
 return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.current_user_role()
returns text language sql stable security definer set search_path=public as $$
 select role from public.profiles where id=auth.uid()
$$;

alter table public.profiles enable row level security;
alter table public.customers enable row level security;
alter table public.vehicles enable row level security;
alter table public.vehicle_images enable row level security;
alter table public.sales enable row level security;
alter table public.loan_applications enable row level security;
alter table public.loan_agreements enable row level security;
alter table public.loan_rate_periods enable row level security;
alter table public.repayment_schedules enable row level security;
alter table public.payments enable row level security;
alter table public.payment_allocations enable row level security;
alter table public.payment_receipts enable row level security;
alter table public.expenses enable row level security;
alter table public.suppliers enable row level security;
alter table public.documents enable row level security;
alter table public.notifications enable row level security;
alter table public.audit_logs enable row level security;
alter table public.company_settings enable row level security;
alter table public.financing_plans enable row level security;
alter table public.vehicle_reservations enable row level security;
alter table public.customer_messages enable row level security;

-- Authenticated staff access is initially broad for core CRM operations.
-- Restrict these policies further by role/customer ownership before public production launch.
create policy "staff read profiles" on public.profiles for select to authenticated using (id=auth.uid() or public.current_user_role()='admin');
create policy "admin update profiles" on public.profiles for update to authenticated using (public.current_user_role()='admin');
create policy "staff manage customers" on public.customers for all to authenticated using (public.current_user_role() in ('admin','sales_officer','loan_officer','accounts_officer')) with check (public.current_user_role() in ('admin','sales_officer','loan_officer','accounts_officer'));
create policy "staff manage vehicles" on public.vehicles for all to authenticated using (public.current_user_role() in ('admin','sales_officer')) with check (public.current_user_role() in ('admin','sales_officer'));
create policy "staff read vehicle images" on public.vehicle_images for select to authenticated using (true);
create policy "staff manage sales" on public.sales for all to authenticated using (public.current_user_role() in ('admin','sales_officer')) with check (public.current_user_role() in ('admin','sales_officer'));
create policy "staff manage applications" on public.loan_applications for all to authenticated using (public.current_user_role() in ('admin','sales_officer','loan_officer')) with check (public.current_user_role() in ('admin','sales_officer','loan_officer'));
create policy "staff read loans" on public.loan_agreements for select to authenticated using (public.current_user_role() in ('admin','loan_officer','accounts_officer'));
create policy "admin insert loans" on public.loan_agreements for insert to authenticated with check (public.current_user_role()='admin');
create policy "staff read rate periods" on public.loan_rate_periods for select to authenticated using (public.current_user_role() in ('admin','loan_officer','accounts_officer'));
create policy "staff read schedules" on public.repayment_schedules for select to authenticated using (public.current_user_role() in ('admin','loan_officer','accounts_officer'));
create policy "accounts read payments" on public.payments for select to authenticated using (public.current_user_role() in ('admin','accounts_officer','loan_officer'));
create policy "accounts insert payments" on public.payments for insert to authenticated with check (public.current_user_role() in ('admin','accounts_officer','loan_officer'));
create policy "admin manage expenses" on public.expenses for all to authenticated using (public.current_user_role()='admin') with check (public.current_user_role()='admin');
create policy "staff read suppliers" on public.suppliers for select to authenticated using (public.current_user_role()='admin');
create policy "staff read documents" on public.documents for select to authenticated using (public.current_user_role() in ('admin','loan_officer','accounts_officer','sales_officer'));
create policy "users read own notifications" on public.notifications for select to authenticated using (user_id=auth.uid() or public.current_user_role()='admin');
create policy "admin read audit" on public.audit_logs for select to authenticated using (public.current_user_role()='admin');
create policy "admin manage settings" on public.company_settings for all to authenticated using (public.current_user_role()='admin') with check (public.current_user_role()='admin');
create policy "staff read financing plans" on public.financing_plans for select to authenticated using (true);
create policy "admin manage plans" on public.financing_plans for all to authenticated using (public.current_user_role()='admin') with check (public.current_user_role()='admin');
create policy "staff manage reservations" on public.vehicle_reservations for all to authenticated using (public.current_user_role() in ('admin','sales_officer')) with check (public.current_user_role() in ('admin','sales_officer'));
create policy "staff manage messages" on public.customer_messages for all to authenticated using (public.current_user_role() in ('admin','sales_officer','loan_officer')) with check (public.current_user_role() in ('admin','sales_officer','loan_officer'));
