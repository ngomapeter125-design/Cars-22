# Backup and recovery

Use Supabase scheduled backups or database exports appropriate to your Supabase plan. Periodically export critical tables and verify that a restore can be completed in a separate test project. Store exports encrypted and restrict access. A backup is not complete until restore testing succeeds.
