# Installation

Requirements: Node.js 20+, npm, a Supabase project and a Netlify account.

1. Extract the ZIP.
2. Run `npm install` in the project root.
3. Copy `.env.example` to `.env.local`.
4. Fill in the Supabase URL and anon key for local development.
5. Run `npm run dev`.
6. Open the local Vite URL shown in the terminal.

For production, set environment variables in Netlify instead of committing `.env`.
