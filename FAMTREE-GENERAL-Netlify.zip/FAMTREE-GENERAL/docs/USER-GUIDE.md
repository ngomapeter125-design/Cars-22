# User guide

1. Sign in with an account created by the administrator.
2. Add vehicles under Vehicles.
3. Register buyers under Customers.
4. Use Loan Calculator to prepare an indicative financing estimate.
5. Submit a loan application under Loans.
6. Have an authorised administrator review and approve it.
7. Record repayments under Payments.
8. Check Dashboard for stock, customer, loan and collection summaries.

The calculator uses a fixed-principal reducing-balance method: each month's rate is the starting rate plus the configured number of percentage points for each elapsed month. Interest is calculated on that month's opening principal balance.
