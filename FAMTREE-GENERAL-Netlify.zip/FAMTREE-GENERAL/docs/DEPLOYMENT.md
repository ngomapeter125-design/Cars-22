# Netlify deployment

1. Push the extracted project to a private GitHub repository.
2. In Netlify, choose Add new site > Import an existing project.
3. Connect the GitHub repository.
4. Build command: `npm run build`
5. Publish directory: `dist`
6. Functions directory: `netlify/functions`
7. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
8. Add server-only `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` for functions that require privileged database access.
9. Add `APP_BASE_URL` using your deployed site URL.
10. Deploy.
11. Create the first administrator and promote the profile as described in DATABASE-SETUP.md.
12. Test login, vehicle creation, customer creation and calculator.

Never expose `SUPABASE_SERVICE_ROLE_KEY` as a VITE_ variable or commit it to GitHub.
Redeploy after changing build-time VITE variables.
