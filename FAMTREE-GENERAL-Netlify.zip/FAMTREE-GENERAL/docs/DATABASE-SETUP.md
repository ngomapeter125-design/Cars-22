# Supabase database setup

1. Create a Supabase project.
2. Open SQL Editor.
3. Run `database/schema.sql`.
4. Enable Email authentication.
5. Create the first user in Authentication > Users.
6. Copy that user's UUID.
7. Run `update public.profiles set role='admin' where id='YOUR-USER-UUID';`
8. Create a private Storage bucket named `customer-documents`.
9. Add appropriate Storage policies before uploading sensitive documents.

The schema starts new users as sales officers. Promote only a trusted first administrator.
Review and tighten all RLS policies and customer ownership rules before production.
