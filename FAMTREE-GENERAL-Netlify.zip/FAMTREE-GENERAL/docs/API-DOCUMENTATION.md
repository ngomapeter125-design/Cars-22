# Netlify Functions

- `POST /.netlify/functions/calculate-loan` calculates a progressive reducing-balance schedule.
- `POST /.netlify/functions/record-payment` records a payment after authentication and role checks.
- `POST /.netlify/functions/approve-loan` allows an admin to approve a pending application and create an active loan record.
- `generate-receipt`, `generate-agreement`, `generate-report`, `send-notification` and `admin-operations` are explicitly marked extension points and are not production implementations yet.

All requests should use HTTPS. Pass the Supabase access token in the Authorization: Bearer header.
