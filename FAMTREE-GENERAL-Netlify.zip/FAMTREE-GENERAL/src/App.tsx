import { useEffect, useMemo, useState } from "react";
import { supabase, isConfigured } from "./lib/supabase";
import { calculateProgressiveLoan, money } from "./lib/finance";
import { CarFront, LayoutDashboard, Users, Wallet, FileText, Settings, LogOut, Plus, Search, Menu, X, Calculator, CreditCard, AlertTriangle, CheckCircle2, Database, ExternalLink } from "lucide-react";

type Vehicle = { id: string; stock_number: string; make: string; model: string; year: number; selling_price: number; status: string; photo_url?: string };
type Customer = { id: string; full_name: string; phone: string; nrc?: string };
type Loan = { id: string; loan_number: string; customer_id: string; principal: number; months: number; starting_rate: number; increment_points: number; status: string; customers?: {full_name:string} };
const nav = [
  ["Dashboard", LayoutDashboard], ["Vehicles", CarFront], ["Customers", Users],
  ["Loans", FileText], ["Payments", Wallet], ["Loan Calculator", Calculator], ["Settings", Settings]
] as const;

export default function App() {
  const [section, setSection] = useState("Dashboard");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [query, setQuery] = useState("");
  const [showVehicle, setShowVehicle] = useState(false);
  const [showCustomer, setShowCustomer] = useState(false);
  const [showLoan, setShowLoan] = useState(false);
  const [vehicleForm, setVehicleForm] = useState({stock_number:"",make:"",model:"",year:new Date().getFullYear(),selling_price:0,status:"available"});
  const [customerForm, setCustomerForm] = useState({full_name:"",phone:"",nrc:"",email:""});
  const [loanForm, setLoanForm] = useState({customer_id:"",vehicle_id:"",principal:0,months:12,starting_rate:2,increment_points:1});
  const [paymentForm, setPaymentForm] = useState({loan_id:"",amount:0,method:"Cash",reference:""});
  const [calc, setCalc] = useState({price:200000,depositPercent:50,months:12,startRate:2,increment:1});
  const [busy, setBusy] = useState(false);

  async function loadData() {
    if (!supabase) return;
    setLoading(true);
    const [v,c,l,p] = await Promise.all([
      supabase.from("vehicles").select("*").order("created_at",{ascending:false}),
      supabase.from("customers").select("*").order("created_at",{ascending:false}),
      supabase.from("loan_agreements").select("*, customers(full_name)").order("created_at",{ascending:false}),
      supabase.from("payments").select("*").order("paid_at",{ascending:false})
    ]);
    if (v.data) setVehicles(v.data as Vehicle[]);
    if (c.data) setCustomers(c.data as Customer[]);
    if (l.data) setLoans(l.data as Loan[]);
    if (p.data) setPayments(p.data);
    setLoading(false);
  }
  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({data}) => setUser(data.session?.user ?? null));
    const {data:{subscription}} = supabase.auth.onAuthStateChange((_event,session) => setUser(session?.user ?? null));
    return () => subscription.unsubscribe();
  }, []);
  useEffect(() => { if (user) loadData(); }, [user]);
  const totalStock = vehicles.length;
  const available = vehicles.filter(v => v.status === "available").length;
  const activeLoans = loans.filter(l => l.status === "active" || l.status === "approved");
  const outstanding = activeLoans.reduce((s,l) => s + Number(l.principal || 0),0);
  const collected = payments.reduce((s,p) => s + Number(p.amount || 0),0);
  const filteredVehicles = vehicles.filter(v => `${v.make} ${v.model} ${v.stock_number}`.toLowerCase().includes(query.toLowerCase()));
  const calcPrincipal = Math.max(0, calc.price * (1 - calc.depositPercent/100));
  const schedule = useMemo(() => {
    try { return calcPrincipal > 0 ? calculateProgressiveLoan(calcPrincipal,calc.months,calc.startRate,calc.increment) : []; }
    catch { return []; }
  }, [calcPrincipal,calc.months,calc.startRate,calc.increment]);
  const totalInterest = schedule.reduce((s,r)=>s+r.interest,0);
  const totalPayable = schedule.reduce((s,r)=>s+r.instalment,0);

  async function login(e: React.FormEvent) {
    e.preventDefault(); if (!supabase) return;
    setBusy(true); setMessage("");
    const {error} = await supabase.auth.signInWithPassword({email,password});
    setMessage(error?.message || "Signed in."); setBusy(false);
  }
  async function logout() { await supabase?.auth.signOut(); setUser(null); }
  async function saveVehicle(e: React.FormEvent) {
    e.preventDefault(); if (!supabase) return;
    setBusy(true); const {error} = await supabase.from("vehicles").insert(vehicleForm);
    setMessage(error?.message || "Vehicle saved."); setShowVehicle(false); setBusy(false); if (!error) loadData();
  }
  async function saveCustomer(e: React.FormEvent) {
    e.preventDefault(); if (!supabase) return;
    setBusy(true); const {error} = await supabase.from("customers").insert(customerForm);
    setMessage(error?.message || "Customer saved."); setShowCustomer(false); setBusy(false); if (!error) loadData();
  }
  async function saveLoan(e: React.FormEvent) {
    e.preventDefault(); if (!supabase) return;
    if (!loanForm.customer_id || !loanForm.vehicle_id) { setMessage("Select a customer and vehicle."); return; }
    setBusy(true);
    const row = {...loanForm, loan_number:`FT-${Date.now()}`, status:"pending", deposit_amount:0, calculation_method:"reducing_balance_progressive"};
    const {error} = await supabase.from("loan_applications").insert(row);
    setMessage(error?.message || "Loan application submitted for administrator review."); setShowLoan(false); setBusy(false); if (!error) loadData();
  }
  async function savePayment(e: React.FormEvent) {
    e.preventDefault(); if (!supabase) return;
    setBusy(true);
    const {data: {user: current}} = await supabase.auth.getUser();
    const {error} = await supabase.from("payments").insert({...paymentForm, receipt_number:`FTR-${Date.now()}`, received_by:current?.id});
    setMessage(error?.message || "Payment recorded."); setBusy(false); if (!error) loadData();
  }
  const amount = (v:number) => money(Number(v || 0));

  if (!isConfigured) return <div className="setup-screen"><div className="setup-card"><img src="/logo.svg" className="setup-logo"/><h1>Connect your database</h1><p>The FAMTREE GENERAL app is installed, but Supabase has not been configured yet.</p><ol><li>Create a Supabase project.</li><li>Run <code>database/schema.sql</code> in the Supabase SQL Editor.</li><li>Set <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_ANON_KEY</code> in Netlify environment variables.</li><li>Redeploy the site.</li></ol><a href="https://supabase.com/dashboard" target="_blank" rel="noreferrer">Open Supabase <ExternalLink size={15}/></a><p className="muted">See README.md and docs/DEPLOYMENT.md for full instructions. Never put the service-role key in frontend variables.</p></div></div>;

  if (!user) return <div className="login-page"><div className="login-card"><img src="/logo.svg" className="login-logo"/><h1>Welcome back</h1><p>Sign in to the FAMTREE GENERAL management system.</p><form onSubmit={login}><label>Email address<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="admin@example.com"/></label><label>Password<input type="password" required value={password} onChange={e=>setPassword(e.target.value)}/></label><button className="primary full" disabled={busy}> {busy?"Signing in...":"Sign in"} </button></form>{message && <p className="notice">{message}</p>}<small>Accounts are created by the company administrator in Supabase Authentication.</small></div></div>;

  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen?"open":""}`}>
      <div className="side-brand"><img src="/logo-white.svg"/><button className="icon-btn mobile-close" onClick={()=>setMobileOpen(false)}><X/></button></div>
      <div className="nav-label">WORKSPACE</div>
      {nav.map(([name,Icon])=><button key={name} className={`nav-item ${section===name?"active":""}`} onClick={()=>{setSection(name);setMobileOpen(false)}}><Icon size={18}/>{name}</button>)}
      <div className="sidebar-bottom"><div className="user-chip"><div className="avatar">{user.email?.[0]?.toUpperCase()}</div><div><b>{user.email}</b><small>Signed in</small></div></div><button className="nav-item" onClick={logout}><LogOut size={18}/>Sign out</button></div>
    </aside>
    <main className="main">
      <header className="topbar"><button className="icon-btn menu-btn" onClick={()=>setMobileOpen(true)}><Menu/></button><div><span className="eyebrow">FAMTREE GENERAL</span><h2>{section}</h2></div><div className="top-actions"><span className="live-dot"/> Live workspace</div></header>
      <div className="content">
        {message && <div className="notice" onClick={()=>setMessage("")}>{message} <X size={15}/></div>}
        {section==="Dashboard" && <><div className="welcome"><div><h1>Business overview</h1><p>Monitor vehicles, customers, financing and collections.</p></div><button className="primary" onClick={()=>setShowVehicle(true)}><Plus size={17}/> Add vehicle</button></div>
          <div className="stats-grid"><Stat icon={<CarFront/>} label="Total vehicles" value={totalStock}/><Stat icon={<CheckCircle2/>} label="Available stock" value={available}/><Stat icon={<Users/>} label="Customers" value={customers.length}/><Stat icon={<FileText/>} label="Active loans" value={activeLoans.length}/><Stat icon={<Wallet/>} label="Payments collected" value={amount(collected)}/><Stat icon={<CreditCard/>} label="Loan principal" value={amount(outstanding)}/></div>
          <div className="panel"><div className="panel-head"><div><h3>Recent vehicle inventory</h3><p>Latest vehicles added to the system</p></div><button className="text-btn" onClick={()=>setSection("Vehicles")}>View all</button></div><VehicleTable rows={vehicles.slice(0,5)} amount={amount}/></div>
          <div className="panel"><div className="panel-head"><div><h3>Recent loan applications</h3><p>Financing activity</p></div><button className="text-btn" onClick={()=>setSection("Loans")}>View loans</button></div><LoanTable rows={loans.slice(0,5)} amount={amount}/></div>
        </>}
        {section==="Vehicles" && <><PageHead title="Vehicle inventory" subtitle="Manage stock, prices and availability" action={<button className="primary" onClick={()=>setShowVehicle(true)}><Plus size={17}/> Add vehicle</button>}/><div className="toolbar"><div className="search"><Search size={17}/><input placeholder="Search make, model or stock number" value={query} onChange={e=>setQuery(e.target.value)}/></div><span>{filteredVehicles.length} vehicles</span></div><VehicleTable rows={filteredVehicles} amount={amount}/></>}
        {section==="Customers" && <><PageHead title="Customers" subtitle="Customer register and contact details" action={<button className="primary" onClick={()=>setShowCustomer(true)}><Plus size={17}/> Add customer</button>}/><div className="panel"><table><thead><tr><th>Customer</th><th>Phone</th><th>NRC</th></tr></thead><tbody>{customers.map(c=><tr key={c.id}><td>{c.full_name}</td><td>{c.phone}</td><td>{c.nrc||"—"}</td></tr>)}</tbody></table>{!customers.length&&<Empty text="No customers registered yet."/></div></>}
        {section==="Loans" && <><PageHead title="Loan management" subtitle="Applications and approved financing accounts" action={<button className="primary" onClick={()=>setShowLoan(true)}><Plus size={17}/> New application</button>}/><div className="panel"><LoanTable rows={loans} amount={amount}/>{!loans.length&&<Empty text="No loan applications found."/ >}</div></>}
        {section==="Payments" && <><PageHead title="Repayments" subtitle="Record and review customer payments"/><form className="inline-form panel" onSubmit={savePayment}><h3>Record a payment</h3><label>Loan<select required value={paymentForm.loan_id} onChange={e=>setPaymentForm({...paymentForm,loan_id:e.target.value})}><option value="">Select loan</option>{loans.map(l=><option key={l.id} value={l.id}>{l.loan_number}</option>)}</select></label><label>Amount (K)<input type="number" min="0.01" step="0.01" required value={paymentForm.amount||""} onChange={e=>setPaymentForm({...paymentForm,amount:Number(e.target.value)})}/></label><label>Method<select value={paymentForm.method} onChange={e=>setPaymentForm({...paymentForm,method:e.target.value})}><option>Cash</option><option>MTN Mobile Money</option><option>Airtel Money</option><option>Bank transfer</option></select></label><label>Transaction reference<input value={paymentForm.reference} onChange={e=>setPaymentForm({...paymentForm,reference:e.target.value})}/></label><button className="primary" disabled={busy}>Save payment</button></form><div className="panel"><h3>Payment history</h3><table><thead><tr><th>Receipt</th><th>Loan</th><th>Amount</th><th>Method</th><th>Date</th></tr></thead><tbody>{payments.map(p=><tr key={p.id}><td>{p.receipt_number}</td><td>{p.loan_id?.slice(0,8)}</td><td>{amount(p.amount)}</td><td>{p.method}</td><td>{new Date(p.paid_at||p.created_at).toLocaleDateString()}</td></tr>)}</tbody></table></div></>}
        {section==="Loan Calculator" && <><PageHead title="Progressive loan calculator" subtitle="50% deposit with configurable increasing monthly interest"/><div className="calc-layout"><div className="panel"><h3>Financing inputs</h3><div className="form-grid"><label>Vehicle price (K)<input type="number" min="1" value={calc.price} onChange={e=>setCalc({...calc,price:Number(e.target.value)})}/></label><label>Deposit (%)<input type="number" min="50" max="100" value={calc.depositPercent} onChange={e=>setCalc({...calc,depositPercent:Number(e.target.value)})}/></label><label>Duration (months)<input type="number" min="1" max="120" value={calc.months} onChange={e=>setCalc({...calc,months:Number(e.target.value)})}/></label><label>Starting monthly rate (%)<input type="number" min="0" step=".01" value={calc.startRate} onChange={e=>setCalc({...calc,startRate:Number(e.target.value)})}/></label><label>Monthly increase (percentage points)<select value={calc.increment} onChange={e=>setCalc({...calc,increment:Number(e.target.value)})}><option value="1">1 percentage point</option><option value="2">2 percentage points</option></select></label></div><p className="hint"><AlertTriangle size={15}/> Estimate only. The signed financing agreement is the authoritative offer.</p></div><div className="summary-card"><span>Deposit due</span><h2>{amount(calc.price*calc.depositPercent/100)}</h2><span>Financed principal</span><h2>{amount(calcPrincipal)}</h2><span>Total interest</span><h2>{amount(totalInterest)}</h2><span>Total instalments</span><h2>{amount(totalPayable)}</h2><span>Total cost including deposit</span><h2>{amount(calc.price*calc.depositPercent/100+totalPayable)}</h2></div></div><div className="panel"><h3>Monthly repayment schedule</h3><table><thead><tr><th>Month</th><th>Opening balance</th><th>Rate</th><th>Principal</th><th>Interest</th><th>Instalment</th><th>Closing balance</th></tr></thead><tbody>{schedule.map(r=><tr key={r.month}><td>{r.month}</td><td>{amount(r.openingBalance)}</td><td>{r.ratePercent.toFixed(2)}%</td><td>{amount(r.principal)}</td><td>{amount(r.interest)}</td><td><b>{amount(r.instalment)}</b></td><td>{amount(r.closingBalance)}</td></tr>)}</tbody></table></div></>}
        {section==="Settings" && <><PageHead title="Company settings" subtitle="Business identity and financing policy"/><div className="panel settings-panel"><img src="/logo.svg"/><h3>FAMTREE GENERAL</h3><p>Car Dealership & Loan Management</p><p>Phone: 0972512551</p><p>Email: bwalyangulube0210@gmail.com</p><hr/><h3>Default financing policy</h3><p>Required deposit: 50% of vehicle selling price.</p><p>Progressive interest: administrator-configured starting monthly rate and monthly percentage-point increment.</p><p className="hint">This starter release uses the calculator settings for quotations. Configure role policies, rate-plan administration and approval workflows before production use.</p></div></>}
        {loading && <div className="loading">Refreshing records…</div>}
      </div>
    </main>
    {showVehicle&&<Modal title="Add vehicle" close={()=>setShowVehicle(false)}><form onSubmit={saveVehicle}><div className="form-grid"><label>Stock number<input required value={vehicleForm.stock_number} onChange={e=>setVehicleForm({...vehicleForm,stock_number:e.target.value})}/></label><label>Make<input required value={vehicleForm.make} onChange={e=>setVehicleForm({...vehicleForm,make:e.target.value})}/></label><label>Model<input required value={vehicleForm.model} onChange={e=>setVehicleForm({...vehicleForm,model:e.target.value})}/></label><label>Year<input type="number" required value={vehicleForm.year} onChange={e=>setVehicleForm({...vehicleForm,year:Number(e.target.value)})}/></label><label>Selling price (K)<input type="number" min="0" required value={vehicleForm.selling_price} onChange={e=>setVehicleForm({...vehicleForm,selling_price:Number(e.target.value)})}/></label><label>Status<select value={vehicleForm.status} onChange={e=>setVehicleForm({...vehicleForm,status:e.target.value})}><option value="available">Available</option><option value="reserved">Reserved</option><option value="sold">Sold</option></select></label></div><button className="primary full" disabled={busy}>Save vehicle</button></form></Modal>}
    {showCustomer&&<Modal title="Register customer" close={()=>setShowCustomer(false)}><form onSubmit={saveCustomer}><label>Full name<input required value={customerForm.full_name} onChange={e=>setCustomerForm({...customerForm,full_name:e.target.value})}/></label><label>Phone<input required value={customerForm.phone} onChange={e=>setCustomerForm({...customerForm,phone:e.target.value})}/></label><label>NRC number<input value={customerForm.nrc} onChange={e=>setCustomerForm({...customerForm,nrc:e.target.value})}/></label><label>Email<input type="email" value={customerForm.email} onChange={e=>setCustomerForm({...customerForm,email:e.target.value})}/></label><button className="primary full" disabled={busy}>Save customer</button></form></Modal>}
    {showLoan&&<Modal title="New loan application" close={()=>setShowLoan(false)}><form onSubmit={saveLoan}><label>Customer<select required value={loanForm.customer_id} onChange={e=>setLoanForm({...loanForm,customer_id:e.target.value})}><option value="">Select customer</option>{customers.map(c=><option key={c.id} value={c.id}>{c.full_name}</option>)}</select></label><label>Vehicle<select required value={loanForm.vehicle_id} onChange={e=>{const v=vehicles.find(x=>x.id===e.target.value);setLoanForm({...loanForm,vehicle_id:e.target.value,principal:v?Number(v.selling_price)*.5:0})}}><option value="">Select vehicle</option>{vehicles.filter(v=>v.status==="available").map(v=><option key={v.id} value={v.id}>{v.make} {v.model} — {amount(v.selling_price)}</option>)}</select></label><div className="form-grid"><label>Financed balance (50%)<input type="number" value={loanForm.principal} readOnly/></label><label>Months<input type="number" min="1" max="120" value={loanForm.months} onChange={e=>setLoanForm({...loanForm,months:Number(e.target.value)})}/></label><label>Starting rate (%)<input type="number" min="0" step=".01" value={loanForm.starting_rate} onChange={e=>setLoanForm({...loanForm,starting_rate:Number(e.target.value)})}/></label><label>Monthly increase (points)<select value={loanForm.increment_points} onChange={e=>setLoanForm({...loanForm,increment_points:Number(e.target.value)})}><option value="1">1</option><option value="2">2</option></select></label></div><p className="hint">Application is submitted as pending. A properly authorised officer must review and approve it before an agreement is activated.</p><button className="primary full" disabled={busy}>Submit application</button></form></Modal>}
  </div>;
}
function Stat({icon,label,value}:{icon:any,label:string,value:any}){return <div className="stat-card"><div className="stat-icon">{icon}</div><span>{label}</span><strong>{value}</strong></div>}
function PageHead({title,subtitle,action}:{title:string,subtitle:string,action?:any}){return <div className="welcome"><div><h1>{title}</h1><p>{subtitle}</p></div>{action}</div>}
function Empty({text}:{text:string}){return <div className="empty"><Database size={25}/><p>{text}</p></div>}
function VehicleTable({rows,amount}:{rows:Vehicle[],amount:(v:number)=>string}){return <div className="table-wrap"><table><thead><tr><th>Stock no.</th><th>Vehicle</th><th>Year</th><th>Price</th><th>Status</th></tr></thead><tbody>{rows.map(v=><tr key={v.id}><td>{v.stock_number}</td><td><b>{v.make} {v.model}</b></td><td>{v.year}</td><td>{amount(v.selling_price)}</td><td><span className={`status ${v.status}`}>{v.status}</span></td></tr>)}</tbody></table>{!rows.length&&<Empty text="No vehicles added yet."/ >}</div>}
function LoanTable({rows,amount}:{rows:Loan[],amount:(v:number)=>string}){return <div className="table-wrap"><table><thead><tr><th>Loan reference</th><th>Customer</th><th>Principal</th><th>Duration</th><th>Status</th></tr></thead><tbody>{rows.map(l=><tr key={l.id}><td>{l.loan_number}</td><td>{l.customers?.full_name||"Customer record"}</td><td>{amount(l.principal)}</td><td>{l.months} months</td><td><span className={`status ${l.status}`}>{l.status}</span></td></tr>)}</tbody></table></div>}
function Modal({title,close,children}:{title:string,close:()=>void,children:any}){return <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)close()}}><div className="modal"><div className="modal-head"><h3>{title}</h3><button className="icon-btn" onClick={close}><X/></button></div>{children}</div></div>}
