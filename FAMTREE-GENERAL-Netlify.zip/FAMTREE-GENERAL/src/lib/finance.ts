export type ScheduleRow = {
  month: number; openingBalance: number; ratePercent: number;
  principal: number; interest: number; instalment: number; closingBalance: number;
};
export function calculateProgressiveLoan(
  principal: number, months: number, startRatePercent: number, incrementPoints: number
): ScheduleRow[] {
  if (![principal, months, startRatePercent, incrementPoints].every(Number.isFinite) ||
      principal <= 0 || months < 1 || !Number.isInteger(months) ||
      startRatePercent < 0 || incrementPoints < 0) throw new Error("Enter valid positive loan details.");
  const cents = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
  let balance = cents(principal);
  const basePrincipal = cents(principal / months);
  const rows: ScheduleRow[] = [];
  for (let i = 1; i <= months; i++) {
    const opening = balance;
    const principalPart = i === months ? opening : Math.min(opening, basePrincipal);
    const rate = startRatePercent + (i - 1) * incrementPoints;
    const interest = cents(opening * rate / 100);
    const instalment = cents(principalPart + interest);
    balance = cents(Math.max(0, opening - principalPart));
    rows.push({ month: i, openingBalance: opening, ratePercent: rate,
      principal: cents(principalPart), interest, instalment, closingBalance: balance });
  }
  return rows;
}
export const money = (n: number) => new Intl.NumberFormat("en-ZM", {
  style: "currency", currency: "ZMW", maximumFractionDigits: 2
}).format(n);
