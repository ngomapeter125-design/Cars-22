import type { Handler } from "@netlify/functions";
import { createClient } from "@supabase/supabase-js";
export const handler: Handler = async (event) => {
  if(event.httpMethod!=="POST") return {statusCode:405,body:"Method not allowed"};
  const url=process.env.SUPABASE_URL, key=process.env.SUPABASE_SERVICE_ROLE_KEY;
  if(!url||!key) return {statusCode:500,body:JSON.stringify({error:"Server database configuration missing"})};
  const auth=event.headers.authorization||"";
  const db=createClient(url,key);
  const token=auth.replace(/^Bearer\s+/i,"");
  const {data:{user},error:authError}=await db.auth.getUser(token);
  if(authError||!user) return {statusCode:401,body:JSON.stringify({error:"Authentication required"})};
  try {
    const body=JSON.parse(event.body||"{}");
    if(!body.loan_id||!Number.isFinite(body.amount)||body.amount<=0) return {statusCode:400,body:JSON.stringify({error:"A loan and positive payment amount are required"})};
    const {data:profile}=await db.from("profiles").select("role").eq("id",user.id).single();
    if(!profile||!["admin","accounts_officer","loan_officer"].includes(profile.role)) return {statusCode:403,body:JSON.stringify({error:"Insufficient permissions"})};
    const {data:loan,error:loanError}=await db.from("loan_agreements").select("id,status,principal").eq("id",body.loan_id).single();
    if(loanError||!loan||loan.status!=="active") return {statusCode:404,body:JSON.stringify({error:"Active loan not found"})};
    const {data:receipt,error}=await db.from("payments").insert({loan_id:loan.id,amount:body.amount,method:body.method||"Cash",reference:body.reference||null,receipt_number:`FTR-${Date.now()}`,received_by:user.id}).select().single();
    if(error) return {statusCode:400,body:JSON.stringify({error:error.message})};
    return {statusCode:201,body:JSON.stringify({payment:receipt})};
  } catch { return {statusCode:400,body:JSON.stringify({error:"Invalid request"})}; }
};
