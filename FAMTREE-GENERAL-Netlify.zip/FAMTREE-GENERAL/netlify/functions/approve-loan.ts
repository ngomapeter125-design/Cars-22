import type { Handler } from "@netlify/functions";
import { createClient } from "@supabase/supabase-js";
export const handler: Handler = async (event) => {
 if(event.httpMethod!=="POST") return {statusCode:405,body:"Method not allowed"};
 const db=createClient(process.env.SUPABASE_URL||"",process.env.SUPABASE_SERVICE_ROLE_KEY||"");
 const token=(event.headers.authorization||"").replace(/^Bearer\s+/i,"");
 const {data:{user}}=await db.auth.getUser(token);
 if(!user) return {statusCode:401,body:JSON.stringify({error:"Authentication required"})};
 const {data:profile}=await db.from("profiles").select("role").eq("id",user.id).single();
 if(profile?.role!=="admin") return {statusCode:403,body:JSON.stringify({error:"Administrator only"})};
 const {application_id,starting_rate,increment_points,months}=JSON.parse(event.body||"{}");
 if(!application_id||![starting_rate,increment_points,months].every(Number.isFinite)||months<1) return {statusCode:400,body:JSON.stringify({error:"Invalid approval details"})};
 const {data:app,error}=await db.from("loan_applications").select("*").eq("id",application_id).eq("status","pending").single();
 if(error||!app) return {statusCode:404,body:JSON.stringify({error:"Pending application not found"})};
 const {data:loan,error:insertError}=await db.from("loan_agreements").insert({loan_number:app.loan_number,customer_id:app.customer_id,vehicle_id:app.vehicle_id,principal:app.principal,months,starting_rate,increment_points,status:"active",approved_by:user.id}).select().single();
 if(insertError) return {statusCode:400,body:JSON.stringify({error:insertError.message})};
 await db.from("loan_applications").update({status:"approved",reviewed_by:user.id,reviewed_at:new Date().toISOString()}).eq("id",application_id);
 return {statusCode:201,body:JSON.stringify({loan})};
};
