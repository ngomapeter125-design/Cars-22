import type { Handler } from "@netlify/functions";
export const handler: Handler = async (event) => ({statusCode:501,body:JSON.stringify({error:"Use the authenticated Supabase admin workflow. This endpoint is reserved for future audited administration actions."})});
