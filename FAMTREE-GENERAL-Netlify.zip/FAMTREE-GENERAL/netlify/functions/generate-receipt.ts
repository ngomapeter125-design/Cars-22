import type { Handler } from "@netlify/functions";
export const handler: Handler = async (event) => {
 if(event.httpMethod!=="GET") return {statusCode:405,body:"Method not allowed"};
 return {statusCode:501,body:JSON.stringify({error:"Receipt PDF endpoint is a deployment extension point. Use the payment receipt record until a PDF renderer is configured."})};
};
