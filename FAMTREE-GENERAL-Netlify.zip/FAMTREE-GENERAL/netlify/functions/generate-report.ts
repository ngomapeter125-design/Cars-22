import type { Handler } from "@netlify/functions";
export const handler: Handler = async (event) => ({statusCode:501,body:JSON.stringify({error:"Report export endpoint requires a report renderer to be configured."})});
