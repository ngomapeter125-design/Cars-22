import type { Handler } from "@netlify/functions";
export const handler: Handler = async (event) => ({statusCode:501,body:JSON.stringify({error:"Notifications require an explicitly configured email or WhatsApp provider."})});
