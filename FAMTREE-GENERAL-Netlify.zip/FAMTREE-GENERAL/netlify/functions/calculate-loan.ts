import type { Handler } from "@netlify/functions";
import { createClient } from "@supabase/supabase-js";
const cors = {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"Content-Type, Authorization","Access-Control-Allow-Methods":"POST, OPTIONS"};
export const handler: Handler = async (event) => {
  if(event.httpMethod==="OPTIONS") return {statusCode:204,headers:cors,body:""};
  if(event.httpMethod!=="POST") return {statusCode:405,headers:cors,body:JSON.stringify({error:"Method not allowed"})};
  try {
    const {principal,months,startingRate,incrementPoints}=JSON.parse(event.body||"{}");
    if(![principal,months,startingRate,incrementPoints].every(Number.isFinite)||principal<=0||!Number.isInteger(months)||months<1||months>120||startingRate<0||incrementPoints<0) return {statusCode:400,headers:cors,body:JSON.stringify({error:"Invalid loan inputs"})};
    let balance=Math.round(principal*100)/100; const base=Math.round(principal/months*100)/100; const rows=[];
    for(let i=1;i<=months;i++){const opening=balance;const p=i===months?opening:Math.min(opening,base);const rate=startingRate+(i-1)*incrementPoints;const interest=Math.round(opening*rate)/100;const instalment=Math.round((p+interest)*100)/100;balance=Math.round(Math.max(0,opening-p)*100)/100;rows.push({month:i,openingBalance:opening,ratePercent:rate,principal:p,interest,instalment,closingBalance:balance});}
    return {statusCode:200,headers:{...cors,"Content-Type":"application/json"},body:JSON.stringify({principal,months,totalInterest:rows.reduce((s,r)=>s+r.interest,0),totalInstalments:rows.reduce((s,r)=>s+r.instalment,0),schedule:rows})};
  } catch { return {statusCode:400,headers:cors,body:JSON.stringify({error:"Invalid JSON request"})}; }
};
