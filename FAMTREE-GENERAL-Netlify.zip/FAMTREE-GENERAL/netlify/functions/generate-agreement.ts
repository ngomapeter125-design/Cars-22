import type { Handler } from "@netlify/functions";
export const handler: Handler = async (event) => ({statusCode:501,body:JSON.stringify({error:"Agreement PDF generation is not enabled in this starter package. Configure a server-side PDF renderer before production use."})});
