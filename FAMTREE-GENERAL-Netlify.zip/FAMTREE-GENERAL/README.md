# FAMTREE GENERAL

Car dealership and loan management application for Zambia.

## Included in this package

- React + TypeScript + Vite frontend
- Supabase authentication and PostgreSQL schema
- Netlify configuration and serverless function examples
- FAMTREE GENERAL SVG branding
- Vehicle and customer registration
- Loan application submission
- Progressive reducing-balance loan calculator
- Payment recording interface
- Responsive dashboard
- Deployment and setup documentation

## Financing calculation

Default policy: 50% deposit. The remaining balance is repaid as equal principal portions. Each month's interest is calculated on that month's opening principal at:

`monthly rate = starting rate + (month number - 1) * monthly percentage-point increment`

This is a reducing-balance, fixed-principal method, not a flat-rate loan. Display the complete schedule to the customer before an agreement is signed.

## Important production-readiness notice

This is a deployable starter/MVP, not a fully audited production lending platform. The user interface and core database schema are supplied, but some requested capabilities are not yet implemented end-to-end. In particular, PDF/Excel document generation, full amortisation schedule persistence and allocation, role administration UI, public vehicle catalogue, customer portal, automated reminders, accounting-grade profit reports, secure customer-specific RLS policies and full audit/reversal workflows require further implementation and testing.

The payment UI currently writes to the payments table directly under its RLS policy. For production, route all payment posting through a single database transaction/RPC or a server function with idempotency, schedule allocation, balance validation and audit logging. Do not treat a payment as confirmed until that workflow is implemented and tested.

## Quick start

See `docs/INSTALLATION.md`, `docs/DATABASE-SETUP.md` and `docs/DEPLOYMENT.md`.

## Company

FAMTREE GENERAL  
Phone: 0972512551  
Email: bwalyangulube0210@gmail.com
